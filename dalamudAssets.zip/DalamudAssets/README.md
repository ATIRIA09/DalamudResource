# DalamudAssets
Static assets for Dalamud

All Noto Sans, FontAwesome and Inconsolata fonts are licensed under the [SIL Open Font License](http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL).
Material Design Icons are licensed under the [Apache License Version 2.0](https://www.apache.org/licenses/LICENSE-2.0.txt).
